def convert_temperature(temp, from_unit, to_unit):
    # 将原单位转换为摄氏度
    if from_unit == 'C':
        celsius = temp
    elif from_unit == 'F':
        celsius = (temp - 32) * 5 / 9
    elif from_unit == 'K':
        celsius = temp - 273.15
    else:
        raise ValueError("无效的原单位")

    # 将摄氏度转换为目标单位
    if to_unit == 'C':
        result = celsius
    elif to_unit == 'F':
        result = celsius * 9 / 5 + 32
    elif to_unit == 'K':
        result = celsius + 273.15
    else:
        raise ValueError("无效的目标单位")

    return result

def main():
    print("温度转换程序")
    print("支持的单位：C（摄氏）、F（华氏）、K（开尔文）")

    while True:
        # 输入温度值
        while True:
            temp_input = input("请输入温度值：").strip()
            try:
                temp = float(temp_input)
                break
            except ValueError:
                print("错误：请输入有效的数字。")

        # 输入原单位
        while True:
            from_unit = input("请输入原单位（C/F/K）：").strip().upper()
            if from_unit in ['C', 'F', 'K']:
                break
            else:
                print("错误：单位必须是C、F或K。")

        # 输入目标单位
        while True:
            to_unit = input("请输入目标单位（C/F/K）：").strip().upper()
            if to_unit in ['C', 'F', 'K']:
                break
            else:
                print("错误：单位必须是C、F或K。")

        # 转换并输出结果
        try:
            converted_temp = convert_temperature(temp, from_unit, to_unit)
            print(f"转换结果：{converted_temp:.2f} {to_unit}")
        except ValueError as e:
            print(f"转换错误：{e}")

        # 询问是否继续
        another = input("是否继续转换？（输入Y继续，其他退出）").strip().upper()
        if another != 'Y':
            print("感谢使用，再见！")
            break

if __name__ == "__main__":
    main()