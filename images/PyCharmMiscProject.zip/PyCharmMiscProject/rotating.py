import turtle


# 初始化画布
def init_canvas():
    turtle.title("Turtle绘图实验")
    turtle.speed(0)
    turtle.hideturtle()
    turtle.tracer(0)  # 关闭自动刷新


# 任务1：嵌套彩色五角星
def nested_stars(layers=5, start_size=200):
    colors = ['#FF0000', '#FFD700', '#4169E1', '#32CD32', '#9370DB']
    init_canvas()

    for i in range(layers):
        turtle.penup()
        turtle.goto(22*i, -5*i)  # 垂直偏移形成嵌套效果
        turtle.setheading(0)
        turtle.pendown()

        # 计算当前层参数
        size = start_size * (0.7 ** i)
        color = colors[i % len(colors)]

        # 绘制五角星
        turtle.color(color)
        turtle.begin_fill()
        for _ in range(5):
            turtle.forward(size)
            turtle.right(144)
        turtle.end_fill()

    turtle.update()


# 任务2：参数化正多边形
def draw_polygon(sides=6, color='#FF69B4', size=100):
    init_canvas()
    turtle.penup()
    turtle.goto(-size / 2, -size / 2)
    turtle.setheading(0)
    turtle.pendown()

    # 设置颜色
    turtle.color(color)
    turtle.begin_fill()

    # 计算角度并绘制
    angle = 360 / sides
    for _ in range(sides):
        turtle.forward(size)
        turtle.left(angle)

    turtle.end_fill()
    turtle.update()


# 任务3：动态旋转花瓣
def rotating_flower(petals=24, size=80):
    init_canvas()
    colors = ['#FF1493', '#FF4500', '#FFD700', '#7FFF00', '#00BFFF']

    for i in range(petals):
        # 设置颜色和角度
        turtle.color(colors[i % len(colors)])
        angle = 360 / petals * i

        # 定位并绘制单个花瓣
        turtle.penup()
        turtle.home()
        turtle.setheading(angle)
        turtle.forward(size / 3)
        turtle.pendown()

        # 绘制花瓣形状
        turtle.begin_fill()
        turtle.circle(size, 60)
        turtle.left(120)
        turtle.circle(size, 60)
        turtle.end_fill()

        turtle.update()  # 逐步显示绘制过程


# 主程序
if __name__ == "__main__":
    # 绘制嵌套五角星
    nested_stars()
    turtle.clearscreen()

    # 绘制正六边形
    draw_polygon(6, '#FF69B4', 150)
    turtle.clearscreen()

    # 绘制旋转花瓣
    rotating_flower()
    turtle.done()
